#  Created by Artem Manchenkov
#  artyom@manchenkoff.me
#
#  Copyright © 2019
#
#  Библиотека Twisted
#
#  https://twistedmatrix.com/
#  https://pypi.org/project/Twisted/
#
#  Работа с TCP протоколами Twisted, базовой сервер
#
#  1. pip install twisted - установка пакета
#  2. from twisted import ... - подключить в файле .py
#
