#  Created by Artem Manchenkov
#  artyom@manchenkoff.me
#
#  Copyright © 2019
#
#  Работа с функциями, аргументы и возвращаемое значение
#
