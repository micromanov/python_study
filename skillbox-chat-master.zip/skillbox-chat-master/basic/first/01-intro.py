#  Created by Artem Manchenkov
#  artyom@manchenkoff.me
#
#  Copyright © 2019
#
#  Примеры базового синтаксиса и работа с типами данных, операторы языка
#  Числа, строки, списки, булево значение
#
