#  Created by Artem Manchenkov
#  artyom@manchenkoff.me
#
#  Copyright © 2019
#
#  Базовые операции языка
#

# Объявление переменных
a = 10
b = 15 + 14
c = a * 2
d = b + c

# Вывод данных
print(10)
print(a)
print("Hello world")
print("Hello ", "YourName")

# Ввод данных
your_name = input("Enter your first name: ")
your_age = int(input("Enter your age: "))  # преобразовали в int число
